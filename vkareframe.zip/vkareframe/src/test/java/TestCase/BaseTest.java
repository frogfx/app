package TestCase;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import Utility.propertyreader;

public class BaseTest {
	public static WebDriver driver;
	public static String SystemPath = System.getProperty("user.dir");
	public static String globalURL;
	public static String pathToExcel;
	public static String fdriverpath;
	public static String idriverpath;
	propertyreader propReader;

	//Run Before WEvery Suite paramtere to pass in testng xml

	@BeforeSuite
	public void init() throws FileNotFoundException, IOException{

propReader=new propertyreader();
		
		globalURL=propertyreader.SiteURL;
		System.out.println("=========BaseTest>>"+globalURL);
		pathToExcel=propertyreader.DataPath;
		System.out.println("=========BaseTest>>"+pathToExcel);
	}
	@Parameters("browser")
	@BeforeTest
	public WebDriver CDriver(String Browsername) throws FileNotFoundException, IOException {
		System.out.println(Browsername+".................");
	
		
		 
		switch (Browsername) {
		case "chrome":
		
			idriverpath=propertyreader.chromeDriver;
			System.out.println("=========BaseTest>>"+idriverpath);
			driver = initchromeDriver(idriverpath,globalURL);

			break;
		case "firefox":
			fdriverpath=propertyreader.FireFoxwebdriver;
			driver = initFirefoxDriver(fdriverpath,globalURL);
			break;
		default:
			fdriverpath=propertyreader.FireFoxwebdriver;
			System.out.println("browser : " + Browsername + " is invalid, Launching Firefox as browser of choice..");
			driver = initFirefoxDriver(fdriverpath,globalURL);
		}
		return driver;

	}

	@AfterTest
	public void disposeDriver() {
		driver.close();
		System.out.println("Endig Browser");
		driver = null;

	}

	private static WebDriver initchromeDriver(String pathtoDriver,String globalURL) throws IOException {
		System.out.println("Launching chrome with new profile..");
		//Runtime.getRuntime().exec(pathToExcel);
		System.setProperty("webdriver.chrome.driver", pathtoDriver);
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		 driver.navigate().to(globalURL);
		
		return driver;
	}

	private static WebDriver initFirefoxDriver(String pathtoDriver,String globalURL) {

		System.setProperty("webdriver.gecko.driver", pathtoDriver);
		DesiredCapabilities cap = new DesiredCapabilities();
		driver = new FirefoxDriver(cap);
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.navigate().to(globalURL);
		System.out.println("Opening Browser");
		driver.manage().window().maximize();
		

		return driver;
	}

	public static WebDriver getDriver() {
		// TODO Auto-generated method stub
		return driver;
	}
}
