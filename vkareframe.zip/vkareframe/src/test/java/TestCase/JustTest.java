package TestCase;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utility.ReadExceltoArray;
import pages.HomePage;
import pages.LoginPage;
import pages.RegistrationCompletePage;
import pages.RegistrationPage;

class JustTest extends BaseTest {
	// LoginPage loginpage;
	HomePage homepage;
	


	@Test(description = "Successful Registration Test ", dataProvider = "RegistrationData")
	public void RegistrationTesta(String sa, String s2, String s3, String s4, String s5, String s6, String s7,
			String s8, String s9, String s10, String s11, String s12, String s13) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// GoToHomePage
		homepage = new HomePage(driver);
		
		// VerifyTitle of HomePage
		Assert.assertTrue(homepage.getHomeTitle().contains("Welcome: Mercury Tours"));
		
		// Click on Registration Link
		RegistrationPage rp = homepage.openRegistrationPage();
	
		// Verify RegistrationPage Title
		Assert.assertTrue(rp.getTitleofReg().contains("Register: Mercury Tours"));
		
		// Fill out the registration Detail and click register
		RegistrationCompletePage rcp = rp.userlogin(sa, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13);
	
		// Assert for the new registration Completed Page
		Assert.assertTrue(rcp.checkSuccessfulRegistration());
		//Log out from here
		rcp.logout();
		
	}

	@DataProvider(name = "RegistrationData")

	public Object[][] Authentication() throws Exception {

		Object[][] testObjArray = ReadExceltoArray.getTableArray(pathToExcel, "Sheet1");
		return (testObjArray);

	}
}
