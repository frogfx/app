package TestCase;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utility.ReadExceltoArray;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends BaseTest{
	HomePage homepage;

	@Test(description = "Login Test using Successful ", dataProvider = "Authentication")
	public void LoginTest1(String sa, String s2, String s3, String s4, String s5, String s6, String s7,
			String s8, String s9, String s10, String Username, String s12, String password)  throws InterruptedException, IOException{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// GoToHomePage
		homepage = new HomePage(driver);
	
		
		// VerifyTitle of HomePage
		assertTrue(homepage.getHomeTitle().contains("Welcome: Mercury Tours"));
	
		// Fill in Login Information anmd Submit
		LoginPage loginpg = homepage.loginwithValidCredential(Username, password);

		// Verify Successfull Title
		assertTrue(loginpg.checkforSuccesfulLogin());
		
	}
	@DataProvider(name = "Authentication")

	public Object[][] Authentication() throws Exception {
	
		Object[][] testObjArray = ReadExceltoArray.getTableArray(pathToExcel, "Sheet1");
		return (testObjArray);

	}
}
