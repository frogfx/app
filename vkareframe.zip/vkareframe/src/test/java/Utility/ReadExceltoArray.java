package Utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Footer;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExceltoArray {
	private static XSSFSheet wsheet;
	private static XSSFWorkbook wBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;
	private static XSSFCell Colu;
	

public static Object[][] getTableArray(String FilePath, String SheetName) throws Exception {   

   String[][] tabArray = null;

   try {
	   FileInputStream ExcelFile = new FileInputStream(FilePath);
	  // System.out.println(FilePath+"....................");
	   // Access the required test data sheet
	   wBook = new XSSFWorkbook(ExcelFile);
	   wsheet = wBook.getSheet(SheetName);
	   int startRow = 1;
	   int startCol = 0;
	   int totalRows = wsheet.getLastRowNum();
	   int totalColumns=wsheet.getRow(0).getLastCellNum();
System.out.println(totalRows+":"+totalColumns);
	   tabArray=new String[totalRows][totalColumns];

int ci,cj;
	   ci=0;
	   for (int i=startRow;i<=totalRows;i++,ci++) {           	   
		   System.out.println("Row num:-"+i);
		   
		cj=0;

		   for (int j=startCol;j<=totalColumns-1;j++,cj++){
			  // System.out.println("Col num:-"+j);
//if(getCellData(i,j)!=null){
			   tabArray[ci][cj]=getCellData(i,j);

			 // System.out.println(tabArray[ci][cj]);  
//}
				}

			}
	  /* Iterator<Row> row=wsheet.rowIterator();
	   Iterator<Cell> cell=Row.cellIterator();
while(row.hasNext()){
	while(cell.hasNext()){
		System.out.println(cell.toString()+"::");
	}*/
	
//}
		}

	catch (FileNotFoundException e){

		System.out.println("Could not read the Excel sheet");

		e.printStackTrace();

		}

	catch (IOException e){

		System.out.println("Could not read the Excel sheet");

		e.printStackTrace();

		}

	return(tabArray);

}


public static String getCellData(int RowNum, int ColNum) throws Exception {

	try{
DataFormatter df=new DataFormatter();

		Cell = wsheet.getRow(RowNum).getCell(ColNum);

		Cell.setCellType(Cell.CELL_TYPE_STRING);
		
			String CellData = df.formatCellValue(Cell);
			
			//System.out.println(CellData);
			return CellData;

		}catch (Exception e){

		System.out.println(e.getMessage());

		throw (e);

		}
}




}
