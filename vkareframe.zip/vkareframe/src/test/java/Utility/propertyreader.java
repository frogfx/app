package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class propertyreader {
public static String SiteURL="";
public static String DataPath="";
public static String FireFoxwebdriver="";
public static String internetexplorerDriver="";
public static String chromeDriver="";
public static String SystemPath = System.getProperty("user.dir");

public propertyreader() throws FileNotFoundException,IOException{
	File fil=new File("testdata//config.properties");
	FileInputStream file=new FileInputStream(fil);
	
	Properties pro=new Properties();
	pro.load(file);
	SiteURL=pro.getProperty("URL");
	System.out.println("=========propertyreader>>"+SiteURL);
	DataPath=SystemPath+pro.getProperty("ExcelData");
	FireFoxwebdriver=SystemPath+pro.getProperty("Firefoxgecko");
	internetexplorerDriver=SystemPath+pro.getProperty("IEDriver");
	chromeDriver=SystemPath+pro.getProperty("ChromeDriver");
}


public void readproperty() throws IOException{
	/*File fil=new File("config.properties");
	FileInputStream file=new FileInputStream(fil);
	
	Properties pro=new Properties();
	pro.load(file);
	URL=pro.getProperty("URL");
	DataPath=pro.getProperty("ExcelData");*/
	
	
}

}
