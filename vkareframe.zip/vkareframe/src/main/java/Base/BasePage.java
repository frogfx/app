package Base;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BasePage {


protected static WebDriver driver;
static String driverPath = "E:\\drivers\\";

/*static PropertiesFileReader prreader = new PropertiesFileReader();
//private static String browserType = prreader.getPropertyvalues("BROWSER_TYPE");
private static String appURL = prreader.getPropertyvalues("APPLICATION_URL");
*/


public static void setDriver(String browserTypename)
{
	switch (browserTypename)
	{
	case "chrome":
		driver = initChromeDriver();
		break;
	case "firefox":
		driver = initFirefoxDriver();
		break;
	default:
		System.out.println("browser : " + browserTypename + " is invalid, Launching Firefox as browser of choice..");
		driver = initFirefoxDriver();
	}
}

private static WebDriver initChromeDriver()
{
	System.out.println("Launching google chrome with new profile..");
	;
	System.setProperty("webdriver.chrome.driver", driverPath + "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	//driver.navigate().to(appURL);
	return driver;
}

private static WebDriver initFirefoxDriver()
{
	System.out.println("Launching Firefox browser..");
	// System.setProperty("webdriver.gecko.driver", driverPath
	// + "geckodriver.exe");
	WebDriver driver = new FirefoxDriver();
	driver.manage().window().maximize();
	//driver.navigate().to(appURL);
	return driver;
}


public static void closeBrowser()
{
	driver.quit();
}

public static WebDriver getDriver()
{
	// TODO Auto-generated method stub
	return driver;
}
}