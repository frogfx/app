package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {

	public  WebDriver driver;


	public HomePage(WebDriver driver) {
		this.driver = driver;
		driver.get("http://newtours.demoaut.com/");
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(name = "userName")
	private WebElement Username;

	@FindBy(name = "password")
	private WebElement Password;

	@FindBy(name = "login")
	private WebElement SubmitLogin;

	@FindBy(linkText = "REGISTER")
	private WebElement registerLink;

	public  String getHomeTitle() {
		 System.out.println(driver.getTitle());
		return driver.getTitle();

	}
	public void setUsername(String uname) {
		Username.clear();
		Username.sendKeys(uname);
		Username.sendKeys(Keys.TAB);
		
	}

	public void setPassword(String pwd) {
		Password.clear();
		Password.sendKeys(pwd);
		Password.sendKeys(Keys.TAB);
	}

	// open Registration Page
	public RegistrationPage openRegistrationPage() throws InterruptedException {
		System.out.println("LoginPage opening");
		
		registerLink.click();
		Thread.sleep(3000);

		return new RegistrationPage(driver);

	}
	
	//Login to application

	public LoginPage loginwithValidCredential(String Uname,String pwd) throws InterruptedException {
	
		setUsername(Uname);
		
		setPassword(pwd);
		//Password.submit();
		SubmitLogin.click();
		
	
		return new LoginPage(driver);

	}
}
