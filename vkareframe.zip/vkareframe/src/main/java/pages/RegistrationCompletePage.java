package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationCompletePage {
	private WebDriver driver;

	public RegistrationCompletePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ".//table/tbody/tr[3]/td/p[2]/font")
	private WebElement Thankyoutext;
	
	@FindBy(linkText = "SIGN-OFF")
	private WebElement signof;

	// Checking Successful Registration by Thankyou Message
	public boolean checkSuccessfulRegistration() {
		boolean registered = Thankyoutext.getText().contains("Thank you for registering");
		return registered;

	}
	public void logout() throws InterruptedException {
		signof.click();
		

	}

}
