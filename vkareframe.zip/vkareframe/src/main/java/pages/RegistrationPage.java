package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
	private WebDriver driver;
	
public RegistrationPage(WebDriver driver){
	this.driver=driver;
	PageFactory.initElements(driver, this);
	
}

	@FindBy(name = "firstName")
	private WebElement firstName;

	@FindBy(name = "lastName")
	private WebElement lastName;

	@FindBy(name = "phone")
	private WebElement phone;

	@FindBy(id = "userName")
	private WebElement email;

	@FindBy(name = "address1")
	private WebElement address1;

	@FindBy(name = "address2")
	private WebElement address2;

	@FindBy(name = "city")
	private WebElement city;

	@FindBy(name = "state")
	private WebElement state;

	@FindBy(name = "postalCode")
	private WebElement postalCode;

	@FindBy(name = "country")
	private WebElement country;

	@FindBy(name = "email")
	private WebElement userName;

	@FindBy(name = "password")
	private WebElement password;

	@FindBy(name = "confirmPassword")
	private WebElement confirmPassword;

	@FindBy(name = "register")
	private WebElement register;

	public void sendFirstname(String fname) {
		firstName.clear();
		firstName.sendKeys(fname);
	}

	public void sendLastname(String lname) {
		lastName.clear();
		lastName.sendKeys(lname);
	}

	public void sendPhone(String mphone) {
		phone.clear();
		phone.sendKeys(mphone);

	}

	public void sendUserName(String uname) {
		System.out.println("uname");
		userName.clear();
		userName.sendKeys(uname);

	}

	public void sendAddress1(String add1) {
		address1.clear();
		address1.sendKeys(add1);

	}

	public void sendAddress2(String add2) {
		address2.clear();
		address2.sendKeys(add2);

	}

	public void sendCity(String icity) {
		city.clear();
		city.sendKeys(icity);

	}

	public void sendState(String istate) {
		state.clear();
		state.sendKeys(istate);

	}

	public void sendPostalCode(String Pcode) {
		postalCode.clear();
		postalCode.sendKeys(Pcode);

	}

	public void sendCountry(String Ctry) {
		Select select = new Select(country);
		select.selectByVisibleText(Ctry.toUpperCase());

	}

	public void sendEmail(String iemail) {

		email.clear();
		email.sendKeys(iemail);
	}

	public void sendPassword(String pwd) {
		password.clear();
		password.sendKeys(pwd);

	}

	public void sendConfirmPassword(String cpwd) {
		confirmPassword.clear();
		confirmPassword.sendKeys(cpwd);
	}

	public RegistrationCompletePage userlogin(String fname, String lname, String mphone, String iemail, String add1, String add2, String icity, String istate, String Pcode, String Ctry, String uname, String pwd, String cpwd) throws InterruptedException {
		this.sendFirstname(fname);
		this.sendLastname(lname);
		this.sendPhone(mphone);
		
		this.sendEmail(iemail);
		this.sendAddress1(add1);
		this.sendAddress2(add2);
		this.sendCity(icity);
		this.sendState(istate);
		this.sendPostalCode(Pcode);
		this.sendCountry(Ctry);
		
		this.sendUserName(uname);
		this.sendPassword(pwd);
		this.sendConfirmPassword(cpwd);
		
		
		this.register.click();
		
		return new RegistrationCompletePage(driver);

	}
	
	public String  getTitleofReg() {
	return driver.getTitle();
	}

}
